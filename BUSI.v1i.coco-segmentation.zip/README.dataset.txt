# BUSI > 2025-05-26 8:57pm
https://universe.roboflow.com/testnaba/busi-4zhoz

Provided by a Roboflow user
License: CC BY 4.0

