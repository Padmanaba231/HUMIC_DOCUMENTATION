# BUSI_MALIGANT > 2025-05-30 8:48am
https://universe.roboflow.com/testnaba/busi_maligant

Provided by a Roboflow user
License: CC BY 4.0

